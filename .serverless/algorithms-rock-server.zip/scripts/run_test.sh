
echo "coming here"
pwd
cd /app
npm install
npm run test

echo "Running lint tests"

npm run lint
