echo "Creating a new image with name algorithms-rock-server"

docker build -t algorithms-rock-server .