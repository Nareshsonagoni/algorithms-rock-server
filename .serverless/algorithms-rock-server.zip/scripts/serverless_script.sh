
docker run -v /Users/kkisha/Desktop/Projects/algorithms-rock-server:/app \
  -it \
  -w /app \
  --rm  serverlesspolska/serverless-framework scripts/serverless_deploy.sh