
serverless config credentials --provider aws --key AKIA55QE67I5I2U2G4VY --secret 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
# Don't follow this method(providing credentials is a bad practice)
serverless deploy -v